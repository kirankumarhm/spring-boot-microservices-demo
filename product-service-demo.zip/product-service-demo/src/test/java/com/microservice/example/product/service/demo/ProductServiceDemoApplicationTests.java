package com.microservice.example.product.service.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
