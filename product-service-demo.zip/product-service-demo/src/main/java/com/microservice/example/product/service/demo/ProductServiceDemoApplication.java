package com.microservice.example.product.service.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceDemoApplication.class, args);
	}

}
