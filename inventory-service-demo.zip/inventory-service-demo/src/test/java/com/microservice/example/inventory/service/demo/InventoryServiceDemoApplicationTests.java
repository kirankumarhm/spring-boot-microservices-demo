package com.microservice.example.inventory.service.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
