package com.microservice.example.order.service.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceDemoApplication.class, args);
	}

}
