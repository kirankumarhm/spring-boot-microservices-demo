package com.microservice.example.order.service.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
